﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Arcillas_UserManagement.Models;

public partial class User
{
    public int Id { get; set; }


    [Required(ErrorMessage = "Please Enter a Username")]
    [MinLength(6, ErrorMessage = "Username is too short minimum 6 characters")]
    [RegularExpression("^[a-zA-Z0-9]+$", ErrorMessage = "Username must not contain special characters")]
    public string Username { get; set; } = null!;

    [Required(ErrorMessage = "Please Enter a Password")]
    [MinLength(8, ErrorMessage = "Password is too short minimun 8 characters")]
    public string Password { get; set; } = null!;

    public virtual ICollection<Person> People { get; set; } = new List<Person>();
}
