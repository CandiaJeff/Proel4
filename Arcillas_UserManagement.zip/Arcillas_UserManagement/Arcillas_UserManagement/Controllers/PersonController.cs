﻿using Arcillas_UserManagement.Context;
using Arcillas_UserManagement.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Arcillas_UserManagement.Controllers
{
    public class PersonController : Controller
    {
        private readonly MyDBContext _context;

        public PersonController(MyDBContext context)
        {
            _context = context;
        }                       
        public IActionResult Index()
        {
            List<Person> people = _context.People.Include(p=> p.User).ToList();
            return View(people);
        }

        //Create
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        //Create Process
        public IActionResult CreateProcess(Person person)
        {
            if (!ModelState.IsValid)
            {
                return View("Create", person);
            }

            person.DateCreated = DateTime.Now;
            _context.People.Add(person);
            _context.SaveChanges();

            return RedirectToAction("Index");
        }

        //Update
        public IActionResult Update(int id)
        {
            Person? person = _context.People.Include(p => p.User).FirstOrDefault(p => p.Id == id);

            return PartialView(person);
        }

        //Update Process
        public IActionResult UpdateProcess(Person person)
        {
            
            person.DateUpdated = DateTime.Now;
            _context.People.Update(person);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }

        //Delete
        public IActionResult Delete(int id)
        {
            Person? person = _context.People.Include(p => p.User).FirstOrDefault(p => p.Id == id);

            if (person is null) return Json(new { success = false, message = "Error! Record not found please try again" });

            _context.Remove(person);
            _context.SaveChanges();

            return Json(new { success = true, message = "Record successfully deleted!" });
        }
    }
}
